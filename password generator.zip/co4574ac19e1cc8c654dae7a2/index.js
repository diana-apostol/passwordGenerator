let paragraphOne= document.getElementById("p1")
let paragraphTwo= document.getElementById("p2")
let paragraphThree= document.getElementById("p3")
let paragraphFour= document.getElementById("p4")
let copyOne= document.getElementById("p1")

//Copy

 
function randomPasswordOne(){
    let characters="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=]}\|,.<>?/"
    return characters[Math.floor(Math.random()* characters.length)];
}

function randomPasswordTwo(){
    let characters="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=]}\|,.<>?/"
    return characters[Math.floor(Math.random()* characters.length)];
}
function randomPasswordThree(){
    let characters="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=]}\|,.<>?/"
    return characters[Math.floor(Math.random()* characters.length)];
}
function randomPasswordFour(){
    let characters="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=]}\|,.<>?/"
    return characters[Math.floor(Math.random()* characters.length)];
}



/*for ( let j= 0; j < 15; j++){
    password= password+ randomPassword()
}*/


function pOne(){
    var passwordOne=""
    for ( let j= 0; j < 15; j++){
    passwordOne= passwordOne+ randomPasswordOne() 
   }
  paragraphOne.textContent= passwordOne
   return passwordOne;
     }
      
   
   
   
function pTwo(){
    var passwordTwo=""
    for ( let k= 0; k < 15; k++){
    passwordTwo= passwordTwo+ randomPasswordTwo() 
   }
  paragraphTwo.textContent= passwordTwo
   return passwordTwo;
   }
 
    
   function pThree(){
       var passwordThree=""
    for ( let l= 0; l < 15; l++){
    passwordThree= passwordThree+ randomPasswordThree() 
   }
  paragraphThree.textContent= passwordThree
   return passwordThree;
   }

   function pFour(){
       var passwordFour=""
    for ( let m= 0; m < 15; m++){
    passwordFour= passwordFour+ randomPasswordFour() 
   }
  paragraphFour.textContent= passwordFour
   return passwordFour;
   }

window.generateRandom = () => alert(pOne(), pTwo(), pThree(), pFour());


//document.getElementById("p1").onclick = function() {pOne()};



 


/*1. un loop sau cv ca atunci cand dai pe generate sa ai max 15 caractere, nu sa vina in cont
2. cum sa faci sa copiezi parola apasand pe butonul cu parola*/